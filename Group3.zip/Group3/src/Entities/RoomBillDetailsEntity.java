/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Lenovo
 */
public class RoomBillDetailsEntity {
    int billnumber,quantity,itemid;
    float price;
    String itemname;

    public RoomBillDetailsEntity() {
        this.billnumber = 0;
        this.itemid = 0;
        this.quantity = 0;
        this.price = 0;
    }
    
    public RoomBillDetailsEntity( String itemname, int quantity, float price) {
        //this.billnmber = billnmber;
        this.itemname = itemname;
        this.quantity = quantity;
        this.price = price;
    }

    public int getBillnumber() {
        return billnumber;
    }

    public void setBillnumber(int billnumber) {
        this.billnumber = billnumber;
    }

    public int getItemid() {
        return itemid;
    }

    public void setItemid(int itemid) {
        this.itemid = itemid;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
    
    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }
    @Override
    public String toString() {
        return "RoomBillDetailsEntity{" + "billnmber=" + billnumber + ", itemid=" + itemid + ", quantity=" + quantity + ", price=" + price + '}';
    }
}
