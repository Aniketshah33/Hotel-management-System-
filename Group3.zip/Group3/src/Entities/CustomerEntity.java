/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Lenovo
 */
public class CustomerEntity {
    int customerId;
    int zipcode,streetNumber,houseNumber;
    String name,phone,email,gender,dateofbirth,securityQuestion,securityAnswer,nameofcompany,pannumber,country,city,username,password,type,cardnumber,expirydate;
    
    public CustomerEntity() {
        this.customerId = 0;
        this.zipcode = 0;
        this.streetNumber = 0;
        this.houseNumber = 0;
        this.name = "";
        this.phone = "";
        this.email = "";
        this.gender = "";
        this.dateofbirth = "";
        this.securityQuestion = "";
        this.securityAnswer = "";
        this.nameofcompany = "";
        this.pannumber = "";
        this.username="";
        this.password="";
        this.country = "";
        this.city = "";
        this.cardnumber = "";
        this.expirydate = "";
        this.type="";
    }
    
    public CustomerEntity(int customerid,String name,String nameofcompany,String pannumber,String type,String email,String phone){
        this.customerId=customerid;
        this.name=name;
        this.nameofcompany=nameofcompany;
        this.pannumber=pannumber;
        this.type=type;
        this.email=email;
        this.phone=phone;
    }
    
    public CustomerEntity(int zipcode, int streetNumber, int houseNumber, String name, String phone, String email, String gender, String dateofbirth, String securityQuestion, String securityAnswer, String nameofcompany, String pannumber, String country, String city, String username, String password, String type, String cardnumber, String expirydate) {
        this.zipcode = zipcode;
        this.streetNumber = streetNumber;
        this.houseNumber = houseNumber;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.gender = gender;
        this.dateofbirth = dateofbirth;
        this.securityQuestion = securityQuestion;
        this.securityAnswer = securityAnswer;
        this.nameofcompany = nameofcompany;
        this.pannumber = pannumber;
        this.country = country;
        this.city = city;
        this.username = username;
        this.password = password;
        this.type = type;
        this.cardnumber = cardnumber;
        this.expirydate = expirydate;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    
    public int getZipcode() {
        return zipcode;
    }

    public void setZipcode(int zipcode) {
        this.zipcode = zipcode;
    }

    public int getStreetNumber() {
        return streetNumber;
    }

    public void setStreetNumber(int streetNumber) {
        this.streetNumber = streetNumber;
    }

    public int getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(int houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public void setSecurityQuestion(String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    public String getSecurityAnswer() {
        return securityAnswer;
    }

    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }

    public String getNameofcompany() {
        return nameofcompany;
    }

    public void setNameofcompany(String nameofcompany) {
        this.nameofcompany = nameofcompany;
    }

    public String getPannumber() {
        return pannumber;
    }

    public void setPannumber(String pannumber) {
        this.pannumber = pannumber;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCardnumber() {
        return cardnumber;
    }

    public void setCardnumber(String cardnumber) {
        this.cardnumber = cardnumber;
    }

    public String getExpirydate() {
        return expirydate;
    }

    public void setExpirydate(String expirydate) {
        this.expirydate = expirydate;
    }

    @Override
    public String toString() {
        return "CustomerEntity{" + "zipcode=" + zipcode + ", streetNumber=" + streetNumber + ", houseNumber=" + houseNumber + ", name=" + name + ", phone=" + phone + ", email=" + email + ", gender=" + gender + ", dateofbirth=" + dateofbirth + ", securityQuestion=" + securityQuestion + ", securityAnswer=" + securityAnswer + ", nameofcompany=" + nameofcompany + ", pannumber=" + pannumber + ", country=" + country + ", city=" + city + ", username=" + username + ", password=" + password + ", type=" + type + ", cardnumber=" + cardnumber + ", expirydate=" + expirydate + '}';
    }
       
}
