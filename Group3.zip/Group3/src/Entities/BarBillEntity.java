/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Lenovo
 */
public class BarBillEntity {
    int roomnumber,discount,tax,staffid,bookingid;
    float totalprice;
    String billdate,customername,address,phone;
    int billnumber;
    float grandtotal;

    public BarBillEntity() {
        this.roomnumber = 0;
        this.totalprice = 0;
        this.discount = 0;
        this.tax = 0;
        this.staffid = 0;
        this.bookingid = 0;
        this.billdate = "";
        this.customername = "";
        this.address = "";
        this.phone = "";
    }
    
    
    public BarBillEntity(int roomnumber, float totalprice, int discount, int tax, int staffid, int bookingid, String billdate, String customername, String address, String phone) {
        this.roomnumber = roomnumber;
        this.totalprice = totalprice;
        this.discount = discount;
        this.tax = tax;
        this.staffid = staffid;
        this.bookingid = bookingid;
        this.billdate = billdate;
        this.customername = customername;
        this.address = address;
        this.phone = phone;
    }
    
    public BarBillEntity(int billnumber,float grandtotal){ 
        this.billnumber=billnumber;
        this.grandtotal=grandtotal;
    }
    public int getBillnumber(){
        return billnumber;
    }
    public void setBillnumber(int billnumber){
        this.billnumber=billnumber;
    }
    public float getGrandtotal(){
        return grandtotal;
    }
    public void setGrandtotal(float grandtotal){
        this.grandtotal=grandtotal;
    }
    public int getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(int roomnumber) {
        this.roomnumber = roomnumber;
    }

    public float getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(float totalprice) {
        this.totalprice = totalprice;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public int getTax() {
        return tax;
    }

    public void setTax(int tax) {
        this.tax = tax;
    }

    public int getStaffid() {
        return staffid;
    }

    public void setStaffid(int staffid) {
        this.staffid = staffid;
    }

    public int getBookingid() {
        return bookingid;
    }

    public void setBookingid(int bookingid) {
        this.bookingid = bookingid;
    }

    public String getBilldate() {
        return billdate;
    }

    public void setBilldate(String billdate) {
        this.billdate = billdate;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "BarBillEntity{" + "roomnumber=" + roomnumber + ", totalprice=" + totalprice + ", discount=" + discount + ", tax=" + tax + ", staffid=" + staffid + ", bookingid=" + bookingid + ", billdate=" + billdate + ", customername=" + customername + ", address=" + address + ", phone=" + phone + '}';
    }
}
