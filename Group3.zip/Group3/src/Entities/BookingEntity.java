package Entities;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Lenovo
 */

public class BookingEntity {
    int customerid,roomnumber,bookingid,staffid;
    String start_Date;
    String end_Date;
    String bookingdate,checkin,checkout;
    String bookingstatus;
    String guestname,phone;

    public BookingEntity() {
        this.customerid = 0;
        this.roomnumber = 0;
        this.bookingid = 0;
        this.staffid = 0;
        this.start_Date = "";
        this.end_Date = "";
        this.bookingdate = "";
        this.checkin = "";
        this.checkout = "";
        this.bookingstatus = "";
    }

    public BookingEntity(int customerid, int roomnumber, int bookingid, int staffid, String start_Date, String end_Date, String bookingdate, String checkin, String checkout, String bookingstatus) {
        this.customerid = customerid;
        this.roomnumber = roomnumber;
        this.bookingid = bookingid;
        this.staffid = staffid;
        this.start_Date = start_Date;
        this.end_Date = end_Date;
        this.bookingdate = bookingdate;
        this.checkin = checkin;
        this.checkout = checkout;
        this.bookingstatus = bookingstatus;
    }
    
    public BookingEntity(int customerid, int roomnumber, int bookingid, int staffid, String start_Date, String end_Date, String bookingdate, String checkin, String checkout, String bookingstatus, String guestname,String phone) {
        this.customerid = customerid;
        this.roomnumber = roomnumber;
        this.bookingid = bookingid;
        this.staffid = staffid;
        this.start_Date = start_Date;
        this.end_Date = end_Date;
        this.bookingdate = bookingdate;
        this.checkin = checkin;
        this.checkout = checkout;
        this.bookingstatus = bookingstatus;
        this.guestname=guestname;
        this.phone=phone;
    }
    
    public int getCustomerid() {
        return customerid;
    }

    public void setCustomerid(int customerid) {
        this.customerid = customerid;
    }
    
    public String getGuestname() {
        return guestname;
    }

    public void setGuestname(String guestname) {
        this.guestname = guestname;
    }
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    public int getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(int roomnumber) {
        this.roomnumber = roomnumber;
    }

    public int getBookingid() {
        return bookingid;
    }

    public void setBookingid(int bookingid) {
        this.bookingid = bookingid;
    }

    public int getStaffid() {
        return staffid;
    }

    public void setStaffid(int staffid) {
        this.staffid = staffid;
    }

    public String getStart_Date() {
        return start_Date;
    }

    public void setStart_Date(String start_Date) {
        this.start_Date = start_Date;
    }

    public String getEnd_Date() {
        return end_Date;
    }

    public void setEnd_Date(String end_Date) {
        this.end_Date = end_Date;
    }

    public String getBookingdate() {
        return bookingdate;
    }

    public void setBookingdate(String bookingdate) {
        this.bookingdate = bookingdate;
    }

    public String getCheckin() {
        return checkin;
    }

    public void setCheckin(String checkin) {
        this.checkin = checkin;
    }

    public String getCheckout() {
        return checkout;
    }

    public void setCheckout(String checkout) {
        this.checkout = checkout;
    }

    public String getBookingstatus() {
        return bookingstatus;
    }

    public void setBookingstatus(String bookingstatus) {
        this.bookingstatus = bookingstatus;
    }

    @Override
    public String toString() {
        return "BookingEntity{" + "customerid=" + customerid + ", roomnumber=" + roomnumber + ", bookingid=" + bookingid + ", staffid=" + staffid + ", start_Date=" + start_Date + ", end_Date=" + end_Date + ", bookingdate=" + bookingdate + ", checkin=" + checkin + ", checkout=" + checkout + ", bookingstatus=" + bookingstatus + '}';
    }
    
}

