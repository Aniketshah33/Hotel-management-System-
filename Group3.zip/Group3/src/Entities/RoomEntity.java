/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Lenovo
 */
public class RoomEntity {
    int roomnumber,price;
    String roomBed,roomType,smoke;
    
    public RoomEntity() {
        this.roomnumber = 0;
        this.price = 0;
        this.roomBed = "";
        this.roomType = "";
        this.smoke = ""; 
    }
    
    public RoomEntity(int roomnumber, int price, String roomBed, String roomType, String smoke) {
        this.roomnumber = roomnumber;
        this.price = price;
        this.roomBed = roomBed;
        this.roomType = roomType;
        this.smoke = smoke;
    }

    public int getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(int roomnumber) {
        this.roomnumber = roomnumber;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getRoomBed() {
        return roomBed;
    }

    public void setRoomBed(String roomBed) {
        this.roomBed = roomBed;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public String getSmoke() {
        return smoke;
    }

    public void setSmoke(String smoke) {
        this.smoke = smoke;
    }

    @Override
    public String toString() {
        return "RoomEntity{" + "roomnumber=" + roomnumber + ", price=" + price + ", roomBed=" + roomBed + ", roomType=" + roomType + ", smoke=" + smoke + '}';
    }
    
    
}
