/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Lenovo
 */
public class InvoiceEntity {
    int invoiceid,bookingid;
    float total,paid;
    String invoicestatus,guestname;

    public InvoiceEntity() {
        this.invoiceid = 0;
        this.bookingid = 0;
        this.total = 0;
        this.paid = 0;
        this.invoicestatus = "";
        this.guestname = "";
    }
    
    
    public InvoiceEntity(int invoiceid, int bookingid, float total, float paid, String invoicestatus, String guestname) {
        this.invoiceid = invoiceid;
        this.bookingid = bookingid;
        this.total = total;
        this.paid = paid;
        this.invoicestatus = invoicestatus;
        this.guestname = guestname;
    }

    public int getInvoiceid() {
        return invoiceid;
    }

    public void setInvoiceid(int invoiceid) {
        this.invoiceid = invoiceid;
    }

    public int getBookingid() {
        return bookingid;
    }

    public void setBookingid(int bookingid) {
        this.bookingid = bookingid;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public float getPaid() {
        return paid;
    }

    public void setPaid(float paid) {
        this.paid = paid;
    }

    public String getInvoicestatus() {
        return invoicestatus;
    }

    public void setInvoicestatus(String invoicestatus) {
        this.invoicestatus = invoicestatus;
    }

    public String getGuestname() {
        return guestname;
    }

    public void setGuestname(String guestname) {
        this.guestname = guestname;
    }

    @Override
    public String toString() {
        return "InvoiceEntity{" + "invoiceid=" + invoiceid + ", bookingid=" + bookingid + ", total=" + total + ", paid=" + paid + ", invoicestatus=" + invoicestatus + ", guestname=" + guestname + '}';
    }
    
}
