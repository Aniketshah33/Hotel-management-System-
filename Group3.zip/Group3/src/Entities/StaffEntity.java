/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import javax.swing.JComboBox;
import javax.swing.JTextField;

/**
 *
 * @author Lenovo
 */
public class StaffEntity {
    int staffId;
    int zipcode,streetnumber,housenumber;
    String name,email,phone,Job,country,city,username,password;
    
    public StaffEntity() {
        this.staffId=0;
        this.zipcode = 0;
        this.streetnumber = 0;
        this.housenumber = 0;
        this.name = "";
        this.email = "";
        this.phone = "";
        this.Job = "";
        this.country = "";
        this.city = "";
        this.username = "";
        this.password = "";
    }
    
    public StaffEntity(int zipcode, int streetnumber, int housenumber, String name, String email, String phone, String Job, String country, String city, String username, String password) {
        this.zipcode = zipcode;
        this.streetnumber = streetnumber;
        this.housenumber = housenumber;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.Job = Job;
        this.country = country;
        this.city = city;
        this.username = username;
        this.password = password;
    }
    
    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }
    
    public int getZipcode() {
        return zipcode;
    }

    public void setZipcode(int zipcode) {
        this.zipcode = zipcode;
    }

    public int getStreetnumber() {
        return streetnumber;
    }

    public void setStreetnumber(int streetnumber) {
        this.streetnumber = streetnumber;
    }

    public int getHousenumber() {
        return housenumber;
    }

    public void setHousenumber(int housenumber) {
        this.housenumber = housenumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getJob() {
        return Job;
    }

    public void setJob(String Job) {
        this.Job = Job;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "AddStaffGS{" + "zipcode=" + zipcode + ", streetnumber=" + streetnumber + ", housenumber=" + housenumber + ", name=" + name + ", email=" + email + ", phone=" + phone + ", Job=" + Job + ", country=" + country + ", city=" + city + ", username=" + username + ", password=" + password + '}';
    }        
}
