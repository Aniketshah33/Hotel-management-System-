/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author Lenovo
 */
public class ThirdPartyDetailsEntity {
    int billnmber,quantity,itemid;
    float price;
    String itemname;

    public ThirdPartyDetailsEntity() {
        this.billnmber = 0;
        this.itemid = 0;
        this.quantity = 0;
        this.price = 0;
    }
    
    public ThirdPartyDetailsEntity( String itemname, int quantity, float price) {
        //this.billnmber = billnmber;
        this.itemname = itemname;
        this.quantity = quantity;
        this.price = price;
    }

    public int getBillnmber() {
        return billnmber;
    }

    public void setBillnmber(int billnmber) {
        this.billnmber = billnmber;
    }

    public int getItemid() {
        return itemid;
    }

    public void setItemid(int itemid) {
        this.itemid = itemid;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
    
    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }
    @Override
    public String toString() {
        return "ThirdPartyDetailsEntity{" + "billnmber=" + billnmber + ", itemid=" + itemid + ", quantity=" + quantity + ", price=" + price + '}';
    }
}
