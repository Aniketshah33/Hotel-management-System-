/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.DriverManager;
import java.util.List;
import Entities.RestaurentBillEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class RestaurentBill {

    private DatabaseParameter database;
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    String HOST;
    int PORT;
    String USER;
    String PASSWORD;
    String DBNAME;
    String DRIVER;
    String URL;

    private Connection connect() {
        Connection conn = null;
        try {
            //connect with database
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return conn;
    }

    public RestaurentBill() throws ClassNotFoundException, SQLException {
        this.database = new DatabaseParameter();
        DBNAME = database.getDBNAME();
        PORT = database.getPORT();
        USER = database.getDbUser();
        PASSWORD = database.getDbPassword();
        HOST = database.getHOST();
        DRIVER = database.getDbDriver();
        URL = database.getDbUrl();
    }

    public int store(RestaurentBillEntity as1) throws SQLException, ClassNotFoundException {
        int billnumber = 0;
        String[] returnid = {"billnumber"};
        LocalDate obj = LocalDate.now();
        String date = obj.toString();
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "INSERT INTO restaurentbill(roomnumber,billdate,customername,address,phone,totalprice,tax,discount,staffid,bookingid) VALUES(?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pstat = conn.prepareStatement(sql, returnid);
            pstat.setInt(1, as1.getRoomnumber());
            pstat.setString(2, date);
            pstat.setString(3, as1.getCustomername());
            pstat.setString(4, as1.getAddress());
            pstat.setString(5, as1.getPhone());
            pstat.setFloat(6, as1.getTotalprice());
            pstat.setInt(7, as1.getTax());
            pstat.setInt(8, as1.getDiscount());
            pstat.setInt(9, as1.getStaffid());
            pstat.setInt(10, as1.getBookingid());
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            //int affectedRows = statement.executeUpdate();

//            if (affectedRows == 0) {
//                throw new SQLException("Creating user failed, no rows affected.");
//            }
            ResultSet generatedKeys = pstat.getGeneratedKeys();
            if (generatedKeys.next()) {
                billnumber = (generatedKeys.getInt(1));
            }
            generatedKeys.close();
            pstat.close();
            conn.close();
            return billnumber;
        } catch (SQLException ex) {
            throw ex;
        }
    }

    public ArrayList<RestaurentBillEntity> getbill(int bookingid) throws SQLException, Exception {
        ArrayList<RestaurentBillEntity> arraylist = new ArrayList<RestaurentBillEntity>();
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "SELECT (totalprice+(totalprice)*((tax-discount)/100)),billnumber FROM restaurentbill WHERE bookingid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, bookingid);

            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arraylist.add(new RestaurentBillEntity(rs.getInt(2), rs.getFloat(1)));
            }
            rs.close();
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return arraylist;
    }
}
