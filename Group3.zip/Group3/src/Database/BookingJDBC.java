/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.DriverManager;
import java.util.List;
import Entities.BookingEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class BookingJDBC {

    private BookingEntity bookingEntity;
    private DatabaseParameter database;
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    String HOST;
    int PORT;
    String USER;
    String PASSWORD;
    String DBNAME;
    String DRIVER;
    String URL;

    private Connection connect() {
        Connection conn = null;
        try {
            //connect with database
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return conn;
    }

    public BookingJDBC() throws ClassNotFoundException, SQLException {
        this.database = new DatabaseParameter();
        DBNAME = database.getDBNAME();
        PORT = database.getPORT();
        USER = database.getDbUser();
        PASSWORD = database.getDbPassword();
        HOST = database.getHOST();
        DRIVER = database.getDbDriver();
        URL = database.getDbUrl();
    }

    public boolean store(BookingEntity c1) throws SQLException, Exception {
        boolean res = false;
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "INSERT INTO booking(startdate,enddate,roomnumber,customerid,bookingdate,bookingstatus,guestname,phone) VALUES(?,?,?,?,?,?,?,?)";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, c1.getStart_Date());
            pstat.setString(2, c1.getEnd_Date());
            pstat.setInt(3, c1.getRoomnumber());
            pstat.setInt(4, c1.getCustomerid());
            pstat.setString(5, c1.getBookingdate());
            pstat.setString(6, c1.getBookingstatus());
            pstat.setString(7, c1.getGuestname());
            pstat.setString(8, c1.getPhone());
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
            res = true;
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return res;
    }

    public ArrayList<BookingEntity> confirm() {
        String a = "unguaranteed";
        String b = "guaranteed";
        ArrayList<BookingEntity> arrayList = new ArrayList<BookingEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM booking WHERE bookingstatus=? OR bookingstatus=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, a);
            pstat.setString(2, b);

            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new BookingEntity(rs.getInt(2), rs.getInt(3), rs.getInt(1), rs.getInt(10), rs.getString(5), rs.getString(6), rs.getString(4), rs.getString(7), rs.getString(8), rs.getString(9)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }

    public void confirm(int bookingid, int staffid) throws SQLException, Exception {
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "UPDATE booking SET bookingstatus=?,staffid=? where bookingid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, "confirmed");
            pstat.setInt(2, staffid);
            pstat.setInt(3, bookingid);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
    }

    public void cancel(int bookingid, int customerid) throws SQLException, Exception {
        LocalDate obj = LocalDate.now();
        String date = obj.toString();
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "UPDATE booking SET bookingstatus=? WHERE customerid=? AND bookingid=? AND startdate>=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, "cancelled");
            pstat.setInt(2, customerid);
            pstat.setInt(3, bookingid);
            pstat.setString(4, date);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
    }

    public ArrayList<BookingEntity> checkIn() {
        String a = "unguaranteed";
        String b = "confirmed";
        ArrayList<BookingEntity> arrayList = new ArrayList<BookingEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM booking WHERE bookingstatus=? OR bookingstatus=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, a);
            pstat.setString(2, b);

            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new BookingEntity(rs.getInt(2), rs.getInt(3), rs.getInt(1), rs.getInt(10), rs.getString(5), rs.getString(6), rs.getString(4), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(11), rs.getString(12)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }

    public void checkIn(int bookingid) throws SQLException, Exception {
        LocalDate obj = LocalDate.now();
        String checkin = obj.toString();
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "UPDATE booking SET bookingstatus=?,checkin=? where bookingid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, "active");
            pstat.setString(2, checkin);
            pstat.setInt(3, bookingid);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
    }

    public int bill(int roomnumber) throws SQLException, Exception {
        int bookingid = 0;
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "SELECT bookingid FROM booking WHERE roomnumber=? AND bookingstatus=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, roomnumber);
            pstat.setString(2, "active");

            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                bookingid = rs.getInt(1);
            }
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return bookingid;
    }

    public ArrayList<BookingEntity> List() {
        ArrayList<BookingEntity> arrayList = new ArrayList<BookingEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM booking";
            PreparedStatement pstat = conn.prepareStatement(sql);
            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new BookingEntity(rs.getInt(2), rs.getInt(3), rs.getInt(1), rs.getInt(10), rs.getString(5), rs.getString(6), rs.getString(4), rs.getString(7), rs.getString(8), rs.getString(9)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }

    public ArrayList<BookingEntity> checkOut() {
        String a = "active";
        ArrayList<BookingEntity> arrayList = new ArrayList<BookingEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM booking WHERE bookingstatus=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, a);

            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new BookingEntity(rs.getInt(2), rs.getInt(3), rs.getInt(1), rs.getInt(10), rs.getString(5), rs.getString(6), rs.getString(4), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(11), rs.getString(12)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }

    public void checkOut(int bookingid) throws SQLException, Exception {
        LocalDate obj = LocalDate.now();
        String checkin = obj.toString();
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "UPDATE booking SET bookingstatus=?,checkin=? where bookingid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, "completed");
            pstat.setString(2, checkin);
            pstat.setInt(3, bookingid);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
    }

    public String guestname(int bookingid) throws SQLException, Exception {
        String guestname = "";
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "SELECT guestname FROM booking WHERE bookingid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, bookingid);

            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                guestname = rs.getString(1);
            }
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return guestname;
    }

    public ArrayList<BookingEntity> customerbooking(int customerid) {
        ArrayList<BookingEntity> arrayList = new ArrayList<BookingEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM booking  WHERE customerid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, customerid);
            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new BookingEntity(rs.getInt(2), rs.getInt(3), rs.getInt(1), rs.getInt(10), rs.getString(5), rs.getString(6), rs.getString(4), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(11), rs.getString(12)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }
    public ArrayList<BookingEntity> Change(int customerId){
        String a="unguaranteed";
        String b="guaranteed";
        ArrayList<BookingEntity> arrayList=new ArrayList<BookingEntity>();
        try{
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM booking WHERE bookingstatus=? OR bookingstatus=? AND customerid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1,a);
            pstat.setString(2,b);
            pstat.setInt(3,customerId);
            
            ResultSet rs = pstat.executeQuery();
                while(rs.next()){
                    arrayList.add(new BookingEntity(rs.getInt(2),rs.getInt(3),rs.getInt(1),rs.getInt(10),rs.getString(5),rs.getString(6),rs.getString(4),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(11),rs.getString(12)));
                }
            pstat.close();
            rs.close();
            conn.close();            
        }
        catch(Exception ex){
            //if any errors occured error message will display
        }
    return arrayList;
    }
    public boolean update(BookingEntity c1,int bookingid) throws SQLException, Exception {
        boolean res = false;
        try{
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql ="UPDATE booking SET startdate=?,enddate=?,roomnumber=?,customerid=?,bookingdate=?,bookingstatus=?,guestname=?,phone=? WHERE bookingid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, c1.getStart_Date());
            pstat.setString(2, c1.getEnd_Date());
            pstat.setInt(3, c1.getRoomnumber());
            pstat.setInt(4, c1.getCustomerid());
            pstat.setString(5,c1.getBookingdate());
            pstat.setString(6, c1.getBookingstatus());
            pstat.setString(7, c1.getGuestname());
            pstat.setString(8, c1.getPhone());
            pstat.setInt(9, bookingid);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
            res = true;
        }
        catch(Exception ex){
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return res;
    }
}
