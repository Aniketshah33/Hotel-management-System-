/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.DriverManager;
import java.util.List;
import Entities.InvoiceEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class Invoice {

    private DatabaseParameter database;
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    String HOST;
    int PORT;
    String USER;
    String PASSWORD;
    String DBNAME;
    String DRIVER;
    String URL;

    private Connection connect() {
        Connection conn = null;
        try {
            //connect with database
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return conn;
    }

    public Invoice() throws ClassNotFoundException, SQLException {
        this.database = new DatabaseParameter();
        DBNAME = database.getDBNAME();
        PORT = database.getPORT();
        USER = database.getDbUser();
        PASSWORD = database.getDbPassword();
        HOST = database.getHOST();
        DRIVER = database.getDbDriver();
        URL = database.getDbUrl();
    }

    public void storedetails(int billnumber, float total_price, String billtype, int invoiceid) throws SQLException, ClassNotFoundException {
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "INSERT INTO invoicedetails (billnumber,total_price,billtype,invoiceid) VALUES(?,?,?,?)";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, billnumber);
            pstat.setFloat(2, total_price);
            pstat.setString(3, billtype);
            pstat.setInt(4, invoiceid);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (SQLException ex) {
            throw ex;
        }
    }

    public int store(int bookingid, String guestname) throws SQLException, ClassNotFoundException {
        int invoiceid = 0;
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "INSERT INTO invoice (bookingid,guestname) VALUES(?,?)";
            PreparedStatement pstat = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            pstat.setInt(1, bookingid);
            pstat.setString(2, guestname);
            invoiceid=pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            //Statement.RETURN_GENERATED_KEYS();
            /*ResultSet generatedKeys = pstat.getGeneratedKeys();
            if (generatedKeys.next()) {
                invoiceid = (generatedKeys.getInt(1));
            }
            generatedKeys.close();*/
            pstat.close();
            conn.close();
            return invoiceid;
        } catch (SQLException ex) {
            throw ex;
        }
    }

    public void update(int invoiceid, float total, float paid, String invoicestatus) throws SQLException, ClassNotFoundException {
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "UPDATE invoice SET total=?,paid=?,invoicestatus=? WHERE invoiceid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setFloat(1, total);
            pstat.setFloat(2, paid);
            pstat.setString(3, invoicestatus);
            pstat.setInt(4, invoiceid);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (SQLException ex) {
            throw ex;
        }
    }

    public ArrayList<InvoiceEntity> List(int customerid) {
        ArrayList<InvoiceEntity> arrayList = new ArrayList<InvoiceEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM invoice where bookingid IN(SELECT bookingid FROM booking WHERE customerid=?)";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, customerid);
            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new InvoiceEntity(rs.getInt(1), rs.getInt(5), rs.getFloat(2), rs.getFloat(3), rs.getString(4), rs.getString(6)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }

    public ArrayList<InvoiceEntity> cooperateList() {
        ArrayList<InvoiceEntity> arrayList = new ArrayList<InvoiceEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM invoice where invoicestatus=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, "pending");
            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new InvoiceEntity(rs.getInt(1), rs.getInt(5), rs.getFloat(2), rs.getFloat(3), rs.getString(4), rs.getString(6)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }

    public void updatepayment(int invoiceid, float total) {
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "UPDATE invoice SET paid=?,invoicestatus=? WHERE invoiceid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setFloat(1, total);
            pstat.setString(2, "paid");
            pstat.setInt(3, invoiceid);
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
    }
}
