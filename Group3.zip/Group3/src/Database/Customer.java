/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Entities.BookingEntity;
import java.sql.DriverManager;
import java.util.List;
import Entities.CustomerEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class Customer {

    private DatabaseParameter database;
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    String HOST;
    int PORT;
    String USER;
    String PASSWORD;
    String DBNAME;
    String DRIVER;
    String URL;

    private Connection connect() {
        Connection conn = null;
        try {
            //connect with database
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return conn;
    }

    public Customer() throws ClassNotFoundException, SQLException {
        this.database = new DatabaseParameter();
        DBNAME = database.getDBNAME();
        PORT = database.getPORT();
        USER = database.getDbUser();
        PASSWORD = database.getDbPassword();
        HOST = database.getHOST();
        DRIVER = database.getDbDriver();
        URL = database.getDbUrl();
    }

    public boolean store(CustomerEntity c1) throws SQLException, Exception {
        boolean res = false;
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "INSERT INTO customer(name,phone,email,gender,dateofbirth,securityquestion,securityanswer,nameofcompany,pannumber,country,city,username,password,type,cardnumber,expirydate,zipcode,streetnumber,housenumber) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, c1.getName());
            pstat.setString(2, c1.getPhone());
            pstat.setString(3, c1.getEmail());
            pstat.setString(4, c1.getGender());
            pstat.setString(5, c1.getDateofbirth());
            pstat.setString(6, c1.getSecurityQuestion());
            pstat.setString(7, c1.getSecurityAnswer());
            pstat.setString(8, c1.getNameofcompany());
            pstat.setString(9, c1.getPannumber());
            pstat.setString(10, c1.getCountry());
            pstat.setString(11, c1.getCity());
            pstat.setString(12, c1.getUsername());
            pstat.setString(13, c1.getPassword());
            pstat.setString(14, c1.getType());
            pstat.setString(15, c1.getCardnumber());
            pstat.setString(16, c1.getExpirydate());
            pstat.setInt(17, c1.getZipcode());
            pstat.setInt(18, c1.getStreetNumber());
            pstat.setInt(19, c1.getHouseNumber());
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
            res = true;
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return res;
    }

    public CustomerEntity Login(CustomerEntity c1) throws SQLException, Exception {
        CustomerEntity ce1 = new CustomerEntity();
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM customer where username=? AND password=? ";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, c1.getUsername());
            pstat.setString(2, c1.getPassword());

            ResultSet rst = pstat.executeQuery();

            while (rst.next()) {
                ce1.setCustomerId(rst.getInt(1));
                ce1.setName(rst.getString(2));
                ce1.setEmail(rst.getString(3));
                ce1.setPhone(rst.getString(4));
                ce1.setDateofbirth(rst.getString(6));
                ce1.setSecurityQuestion(rst.getString(7));
                ce1.setSecurityAnswer(rst.getString(8));
                ce1.setNameofcompany(rst.getString(17));
                ce1.setPannumber(rst.getString(18));
                ce1.setCountry(rst.getString(10));
                ce1.setCity(rst.getString(11));
                ce1.setGender(rst.getString(5));
                ce1.setUsername(rst.getString(15));
                ce1.setPassword(rst.getString(16));
                ce1.setZipcode(rst.getInt(12));
                ce1.setStreetNumber(rst.getInt(13));
                ce1.setHouseNumber(rst.getInt(14));
                //ce1.setRating(rst.getInt(15));
                ce1.setExpirydate(rst.getString(20));
                ce1.setCardnumber(rst.getString(19));
                ce1.setType(rst.getString(9));
                //System.out.println(ce1.toString());
            }
            pstat.close();
            rst.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
        }
        return ce1;
    }

    public boolean check(CustomerEntity c1) throws SQLException, Exception {
        boolean res = false;
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT customerid FROM customer WHERE email=? AND securityquestion=? AND securityanswer=? ";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, c1.getEmail());
            pstat.setString(2, c1.getSecurityQuestion());
            pstat.setString(3, c1.getSecurityAnswer());
            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                //System.out.println(rs.getInt("customerid"));
                res = true;
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return res;
    }

    public void update(CustomerEntity c1, String email) throws SQLException, Exception {
        try {
            //connect with database
            Class.forName(DRIVER);
            //Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            Connection conn = connect();
            //update record on database
            String sql = "UPDATE customer SET password=? WHERE email=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, c1.getPassword());
            pstat.setString(2, email);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
    }

    public ArrayList<CustomerEntity> confirm() {
        String a = "Cooperate_pending";
        ArrayList<CustomerEntity> arrayList = new ArrayList<CustomerEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM customer WHERE type=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, a);
            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new CustomerEntity(rs.getInt(1), rs.getString(2), rs.getString(18), rs.getString(19), rs.getString(9), rs.getString(3), rs.getString(4)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }

    public void client(int customerid) throws SQLException, Exception {
        String str = "cooperate";
        try {
            //connect with database
            Class.forName(DRIVER);
            //Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            Connection conn = connect();
            //update record on database
            String sql = "UPDATE customer SET type=? WHERE customerid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, str);
            pstat.setInt(2, customerid);
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
    }

    public CustomerEntity bill(int roomnumber) throws SQLException, Exception {
        CustomerEntity ce1 = new CustomerEntity();
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM customer WHERE customerid IN(SELECT customerid FROM booking WHERE bookingstatus=? AND roomnumber=?) ";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, "active");
            pstat.setInt(2, roomnumber);
            ResultSet rst = pstat.executeQuery();

            while (rst.next()) {
                ce1.setCustomerId(rst.getInt(1));
                ce1.setName(rst.getString(2));
                ce1.setEmail(rst.getString(3));
                ce1.setPhone(rst.getString(4));
                ce1.setDateofbirth(rst.getString(6));
                ce1.setSecurityQuestion(rst.getString(7));
                ce1.setSecurityAnswer(rst.getString(8));
                ce1.setNameofcompany(rst.getString(17));
                ce1.setPannumber(rst.getString(18));
                ce1.setCountry(rst.getString(10));
                ce1.setCity(rst.getString(11));
                ce1.setGender(rst.getString(5));
                ce1.setUsername(rst.getString(15));
                ce1.setPassword(rst.getString(16));
                ce1.setZipcode(rst.getInt(12));
                ce1.setStreetNumber(rst.getInt(13));
                ce1.setHouseNumber(rst.getInt(14));
                //ce1.setRating(rst.getInt(15));
                ce1.setExpirydate(rst.getString(20));
                ce1.setCardnumber(rst.getString(19));
                ce1.setType(rst.getString(9));
            }
            pstat.close();
            rst.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
        }
        return ce1;
    }

    public ArrayList<CustomerEntity> List() {
        ArrayList<CustomerEntity> arrayList = new ArrayList<CustomerEntity>();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM customer";
            PreparedStatement pstat = conn.prepareStatement(sql);
            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                arrayList.add(new CustomerEntity(rs.getInt(1), rs.getString(2), rs.getString(17), rs.getString(18), rs.getString(9), rs.getString(3), rs.getString(4)));
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return arrayList;
    }

    public CustomerEntity List1(int customerid) {
        CustomerEntity ce1 = new CustomerEntity();
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM customer where customerid=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, customerid);
            ResultSet rst = pstat.executeQuery();
            while (rst.next()) {
                ce1.setCustomerId(rst.getInt(1));
                ce1.setName(rst.getString(2));
                ce1.setEmail(rst.getString(3));
                ce1.setPhone(rst.getString(4));
                ce1.setDateofbirth(rst.getString(6));
                ce1.setSecurityQuestion(rst.getString(7));
                ce1.setSecurityAnswer(rst.getString(8));
                ce1.setNameofcompany(rst.getString(17));
                ce1.setPannumber(rst.getString(18));
                ce1.setCountry(rst.getString(10));
                ce1.setCity(rst.getString(11));
                ce1.setGender(rst.getString(5));
                ce1.setUsername(rst.getString(15));
                ce1.setPassword(rst.getString(16));
                ce1.setZipcode(rst.getInt(12));
                ce1.setStreetNumber(rst.getInt(13));
                ce1.setHouseNumber(rst.getInt(14));
                //ce1.setRating(rst.getInt(15));
                ce1.setExpirydate(rst.getString(20));
                ce1.setCardnumber(rst.getString(19));
                ce1.setType(rst.getString(9));
            }
            pstat.close();
            rst.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return ce1;
    }
}
