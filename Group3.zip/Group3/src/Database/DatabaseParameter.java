/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author lenovo
 */
public class DatabaseParameter {

    private String dbDriver;
    private String dbUrl;
    private String dbUser;
    private String dbPassword;
    private String HOST = "localhost";
    private int PORT = 3306;
    String DBNAME = "hotel_booking";

    public DatabaseParameter() {
        this.dbDriver = "com.mysql.cj.jdbc.Driver";
        this.dbUrl = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DBNAME;
        this.dbUser = "root";
        this.dbPassword = "";
    }

    public String getDbDriver() {
        return dbDriver;
    }

    public String getDbUrl() {
        return dbUrl;
    }

    public String getDbUser() {
        return dbUser;
    }

    public String getDbPassword() {
        return dbPassword;
    }

    public String getHOST() {
        return HOST;
    }

    public int getPORT() {
        return PORT;
    }

    public String getDBNAME() {
        return DBNAME;
    }

}
