/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.DriverManager;
import java.util.List;
import Entities.CustomerEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class Menu {

    public Menu(int aInt, String string, int aInt1) {
    }

    String HOST = "localhost";
    int PORT = 3306;
    String USER = "root";
    String PASSWORD = "";
    String DBNAME = "hotel_booking";
    String DRIVER = "com.mysql.cj.jdbc.Driver";
    String URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DBNAME;

    public Menu() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Connection connect() {
        Connection conn = null;
        try {
            //connect with database
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return conn;
    }

    public ArrayList<String> getAllMenu() throws SQLException, Exception {
        ArrayList<String> menuList;
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            menuList = new ArrayList<>();
            String sql = "SELECT * FROM menu ";
            PreparedStatement pstat = conn.prepareStatement(sql);
            ResultSet rst = pstat.executeQuery();
            while (rst.next()) {
                String menu = rst.getString("itemname");
                menuList.add(menu);
            }
            pstat.close();
            rst.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return menuList;
    }
}
