/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Entities.BookingEntity;
import java.sql.DriverManager;
import java.util.List;
import Entities.RestaurentDetailsEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class RestaurentDetails {

    private BookingEntity bookingEntity;
    private DatabaseParameter database;
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    String HOST;
    int PORT;
    String USER;
    String PASSWORD;
    String DBNAME;
    String DRIVER;
    String URL;

    private Connection connect() {
        Connection conn = null;
        try {
            //connect with database
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return conn;
    }

    public RestaurentDetails() throws ClassNotFoundException, SQLException {
        this.database = new DatabaseParameter();
        DBNAME = database.getDBNAME();
        PORT = database.getPORT();
        USER = database.getDbUser();
        PASSWORD = database.getDbPassword();
        HOST = database.getHOST();
        DRIVER = database.getDbDriver();
        URL = database.getDbUrl();
    }

    public void store(RestaurentDetailsEntity as1, int billnumber) throws SQLException, ClassNotFoundException {
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            //insert record on database
            String sql = "INSERT INTO restaurentdetails (billnumber,itemname,quantity,price) VALUES(?,?,?,?)";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, billnumber);
            pstat.setString(2, as1.getItemname());
            pstat.setInt(3, as1.getQuantity());
            pstat.setFloat(4, as1.getPrice());
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
        } catch (SQLException ex) {
            throw ex;
        }
    }
}
