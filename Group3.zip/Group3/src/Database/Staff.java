/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.DriverManager;
import java.util.List;
import Entities.StaffEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class Staff {

    private DatabaseParameter database;
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    String HOST;
    int PORT;
    String USER;
    String PASSWORD;
    String DBNAME;
    String DRIVER;
    String URL;

    private Connection connect() {
        Connection conn = null;
        try {
            //connect with database
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return conn;
    }

    public Staff() throws ClassNotFoundException, SQLException {
        this.database = new DatabaseParameter();
        DBNAME = database.getDBNAME();
        PORT = database.getPORT();
        USER = database.getDbUser();
        PASSWORD = database.getDbPassword();
        HOST = database.getHOST();
        DRIVER = database.getDbDriver();
        URL = database.getDbUrl();
    }

    public boolean store(StaffEntity as1) throws SQLException, Exception {
        boolean res = false;
        try {
            //connect with database
            Class.forName(DRIVER);
            //Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            Connection conn = connect();
            //insert record on database
            String sql = "INSERT INTO staff(name,email,phone,username,password,job,country,city,zipcode,streetnumber,housenumber) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, as1.getName());
            pstat.setString(2, as1.getEmail());
            pstat.setString(3, as1.getPhone());
            pstat.setString(4, as1.getUsername());
            pstat.setString(5, as1.getPassword());
            pstat.setString(6, as1.getJob());
            pstat.setString(7, as1.getCountry());
            pstat.setString(8, as1.getCity());
            pstat.setInt(9, as1.getZipcode());
            pstat.setInt(10, as1.getStreetnumber());
            pstat.setInt(11, as1.getHousenumber());
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
            res = true;
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return res;
    }

    public StaffEntity Login(StaffEntity c1) throws SQLException, Exception {
        StaffEntity ce1 = new StaffEntity();
        try {
            //connect with database
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT * FROM staff where username=? AND password=? ";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, c1.getUsername());
            pstat.setString(2, c1.getPassword());
            ResultSet rst = pstat.executeQuery();
            while (rst.next()) {
                //if ()
                ce1.setStaffId(rst.getInt(1));
                ce1.setName(rst.getString(2));
                ce1.setEmail(rst.getString(3));
                ce1.setPhone(rst.getString(4));
                ce1.setJob(rst.getString(10));
                ce1.setCountry(rst.getString(5));
                ce1.setCity(rst.getString(6));
                ce1.setZipcode(rst.getInt(7));
                ce1.setStreetnumber(rst.getInt(8));
                ce1.setHousenumber(rst.getInt(9));
                ce1.setUsername(rst.getString(11));
                ce1.setPassword(rst.getString(12));
            }
            pstat.close();
            rst.close();
            conn.close();
        } catch (Exception ex) {
            throw ex;
        }
        return ce1;
    }
}
