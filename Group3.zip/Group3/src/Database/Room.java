/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.DriverManager;
import Entities.RoomEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Room {

    private DatabaseParameter database;
    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    String HOST;
    int PORT;
    String USER;
    String PASSWORD;
    String DBNAME;
    String DRIVER;
    String URL;

    private Connection connect() {
        Connection conn = null;
        try {
            //connect with database
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception ex) {
            System.out.println("Error : " + ex.getMessage());
        }
        return conn;
    }

    public Room() throws ClassNotFoundException, SQLException {
        this.database = new DatabaseParameter();
        DBNAME = database.getDBNAME();
        PORT = database.getPORT();
        USER = database.getDbUser();
        PASSWORD = database.getDbPassword();
        HOST = database.getHOST();
        DRIVER = database.getDbDriver();
        URL = database.getDbUrl();
    }

    public boolean store(RoomEntity as1) throws SQLException, Exception {
        boolean res = false;
        try {
            //connect with database
            Class.forName(DRIVER);
            //Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            Connection conn = connect();
            //insert record on database
            String sql = "INSERT INTO room(roomnumber,price,AC_NonAC,single_double,Smoking_Non_smoking) VALUES(?,?,?,?,?)";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, as1.getRoomnumber());
            pstat.setInt(2, as1.getPrice());
            pstat.setString(4, as1.getRoomBed());
            pstat.setString(3, as1.getRoomType());
            pstat.setString(5, as1.getSmoke());
            pstat.executeUpdate();//Inserting Record, Updating Record, Deleting Record
            pstat.close();
            conn.close();
            res = true;
        } catch (Exception ex) {
            throw ex;
            //System.out.println("Error : "+ ex.getMessage());
            //res = false;
        }
        return res;
    }

    public int search(String roomBed, String roomType, String smoke, String startdate, String enddate, String Bookingstatus) {
        // connect with database
        // select all the records from database
        List<Integer> arrayList = new ArrayList<>();
        int roomnumber = 0;
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT roomnumber FROM room WHERE AC_NonAC=? AND single_double=? AND Smoking_Non_smoking=? AND roomnumber NOT IN(SELECT roomnumber from booking where startdate BETWEEN ? AND ? AND enddate BETWEEN ? AND ?)";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setString(1, roomType);
            pstat.setString(2, roomBed);
            pstat.setString(3, smoke);
            pstat.setString(4, startdate);
            pstat.setString(5, enddate);
            pstat.setString(6, startdate);
            pstat.setString(7, enddate);

            ResultSet rs = pstat.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    arrayList.add(rs.getInt(1));
                }
            } else {
                String query = "SELECT roomnumber FROM room WHERE AC_NonAC=? AND single_double=? AND Smoking_Non_smoking=? AND roomnumber NOT IN(SELECT roomnumber from booking where startdate BETWEEN ? AND ? AND enddate BETWEEN ? AND ? AND bookingstatus=?)";
                PreparedStatement pstat1 = conn.prepareStatement(query);
                pstat1.setString(1, roomType);
                pstat1.setString(2, roomBed);
                pstat1.setString(3, smoke);
                pstat1.setString(4, startdate);
                pstat1.setString(5, enddate);
                pstat1.setString(6, startdate);
                pstat1.setString(7, enddate);
                pstat1.setString(8, Bookingstatus);
                ResultSet rs1 = pstat1.executeQuery();
                while (rs1.next()) {
                    arrayList.add(rs1.getInt(1));
                }
                pstat1.close();
                rs1.close();
            }
            roomnumber = arrayList.get(0);
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return roomnumber;
    }

    public int price(int roomnumber) {
        // connect with database
        // select all the records from database
        int price = 0;
        try {
            //try to connect with datbase
            Class.forName(DRIVER);
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            String sql = "SELECT price FROM room WHERE roomnumber=?";
            PreparedStatement pstat = conn.prepareStatement(sql);
            pstat.setInt(1, roomnumber);

            ResultSet rs = pstat.executeQuery();
            while (rs.next()) {
                price = rs.getInt(1);
            }
            pstat.close();
            rs.close();
            conn.close();
        } catch (Exception ex) {
            //if any errors occured error message will display
        }
        return price;
    }
}
